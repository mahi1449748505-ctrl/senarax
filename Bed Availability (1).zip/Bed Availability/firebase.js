import { initializeApp } from "https://www.gstatic.com/firebasejs/12.17.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.17.0/firebase-analytics.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.17.0/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.17.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyC8D4MXn274qrF8Slo2xa45cwD7lXMcpO4",
  authDomain: "hospital-beds-availability.firebaseapp.com",
  projectId: "hospital-beds-availability",
  storageBucket: "hospital-beds-availability.firebasestorage.app",
  messagingSenderId: "667485844881",
  appId: "1:667485844881:web:568281bef2f138931f1630",
  measurementId: "G-P3DNB09VXB"
};

const app = initializeApp(firebaseConfig);

const analytics = getAnalytics(app);
const db = getFirestore(app);
const auth = getAuth(app);

export { app, db, auth };
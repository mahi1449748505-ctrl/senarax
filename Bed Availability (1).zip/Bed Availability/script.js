function initMap() {

    const center = {
        lat: 13.0827,
        lng: 80.2707
    };

    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: center
    });


    const hospitals = [

        {
            name: "Apollo Hospital",
            lat: 13.0630,
            lng: 80.2490,
            availableBeds: 25,
            icuBeds: 6
        },

        {
            name: "Government General Hospital",
            lat: 13.0818,
            lng: 80.2765,
            availableBeds: 10,
            icuBeds: 3
        },

        {
            name: "Kauvery Hospital",
            lat: 13.0445,
            lng: 80.2420,
            availableBeds: 15,
            icuBeds: 4
        }

    ];


    hospitals.forEach(hospital => {


        const marker = new google.maps.Marker({

            position: {
                lat: hospital.lat,
                lng: hospital.lng
            },

            map: map,

            title: hospital.name

        });



        const infoWindow = new google.maps.InfoWindow({

            content: `

            <div>

            <h3>${hospital.name}</h3>

            <p>
            Available Beds:
            ${hospital.availableBeds}
            </p>

            <p>
            ICU Beds:
            ${hospital.icuBeds}
            </p>


            <button onclick="navigate(${hospital.lat},${hospital.lng})">
            🧭 Get Directions
            </button>


            </div>

            `

        });



        marker.addListener("click",()=>{

            infoWindow.open(map,marker);

        });


    });


}



function navigate(lat,lng){

    const url =
    "https://www.google.com/maps/dir/?api=1&destination="
    + lat + "," + lng;


    window.open(url,"_blank");

}